import { Injectable } from '@nestjs/common';
import { Server, Socket } from 'socket.io';

@Injectable()
export class SocketService {
  private server: Server;

  initialize(server: Server) {
    this.server = server;
    this.server.on('connection', (socket: Socket) => {
      console.log('New client connected:', socket.id);

      socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
      });
    });
  }

  emitEvent(event: string, payload: any) {
    if (this.server) {
      this.server.emit(event, payload);
    }
  }
}
