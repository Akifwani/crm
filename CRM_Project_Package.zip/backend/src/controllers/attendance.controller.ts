import { Controller, Post, Body, Get, Param, Put } from '@nestjs/common';
import prisma from '../config/prisma.client';

@Controller('attendance')
export class AttendanceController {
  @Post('clock-in')
  async clockIn(@Body('userId') userId: string) {
    const clockIn = await prisma.attendance.create({
      data: { userId, clockIn: new Date() },
    });
    return clockIn;
  }

  @Put('clock-out/:id')
  async clockOut(@Param('id') id: string) {
    const clockOut = await prisma.attendance.update({
      where: { id },
      data: { clockOut: new Date() },
    });
    return clockOut;
  }

  @Get(':userId')
  async getAttendance(@Param('userId') userId: string) {
    const attendance = await prisma.attendance.findMany({
      where: { userId },
    });
    return attendance;
  }
}
