import { Controller, Post, Body, Get, Param, Put } from '@nestjs/common';
import { TaskService } from '../services/task.service';

@Controller('tasks')
export class TaskController {
  constructor(private readonly taskService: TaskService) {}

  @Post('create')
  async createTask(@Body() createTaskDto: any) {
    return this.taskService.createTask(createTaskDto);
  }

  @Get(':id')
  async getTask(@Param('id') id: string) {
    return this.taskService.getTask(id);
  }

  @Put('update/:id')
  async updateTask(@Param('id') id: string, @Body() updateTaskDto: any) {
    return this.taskService.updateTask(id, updateTaskDto);
  }
}
