import { Injectable } from '@nestjs/common';
import { Server, Socket } from 'socket.io';

@Injectable()
export class SocketService {
  private server: Server;

  initialize(server: Server) {
    this.server = server;
    this.server.on('connection', (socket: Socket) => {
      console.log('New client connected:', socket.id);

      // Example WebSocket events
      socket.on('taskAssigned', (data) => {
        console.log('Task assigned:', data);
        this.server.emit('notification', `New task assigned: ${data.title}`);
      });

      socket.on('userMentioned', (data) => {
        console.log('User mentioned:', data);
        this.server.emit('notification', `You were mentioned in a task comment: ${data.comment}`);
      });

      socket.on('clockIn', (data) => {
        console.log('Clock-in event:', data);
        this.server.emit('notification', `${data.user} clocked in at ${data.time}`);
      });

      socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
      });
    });
  }

  emitEvent(event: string, payload: any) {
    if (this.server) {
      this.server.emit(event, payload);
    }
  }
}
