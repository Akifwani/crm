import { Injectable } from '@nestjs/common';

@Injectable()
export class TaskService {
  async createTask(createTaskDto: any) {
    // Mocking task creation
    return { id: 1, ...createTaskDto, status: 'created' };
  }

  async getTask(id: string) {
    // Mocking fetching a task by ID
    return { id, name: 'Sample Task', status: 'in-progress' };
  }

  async updateTask(id: string, updateTaskDto: any) {
    // Mocking task update
    return { id, ...updateTaskDto };
  }
}
