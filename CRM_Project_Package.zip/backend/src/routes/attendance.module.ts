import { Module } from '@nestjs/common';
import { AttendanceController } from '../controllers/attendance.controller';

@Module({
  controllers: [AttendanceController],
})
export class AttendanceModule {}
