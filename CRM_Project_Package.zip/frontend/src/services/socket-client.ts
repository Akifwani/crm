import { io } from "socket.io-client";

const socket = io("http://localhost:3001"); // Adjust the backend server URL as necessary

socket.on("connect", () => {
  console.log("Connected to WebSocket server");
});

socket.on("notification", (message) => {
  console.log("Notification received:", message);
});

export default socket;
