import React, { useState } from 'react';

export const Notification = () => {
  const [messages, setMessages] = useState<string[]>([]);

  const addNotification = (message: string) => {
    setMessages([...messages, message]);
  };

  return (
    <div className="fixed bottom-4 right-4 bg-gray-800 text-white p-4 rounded">
      <h2 className="text-lg font-bold">Notifications</h2>
      <ul>
        {messages.map((msg, index) => (
          <li key={index} className="mt-2">{msg}</li>
        ))}
      </ul>
    </div>
  );
};