import React, { useEffect, useState } from "react";
import socket from "../services/socket-client";

export const Dashboard = () => {
  const [notifications, setNotifications] = useState<string[]>([]);

  useEffect(() => {
    socket.on("notification", (message: string) => {
      setNotifications((prev) => [...prev, message]);
    });

    return () => {
      socket.off("notification");
    };
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="mt-4">
        <h2 className="text-lg font-semibold">Notifications</h2>
        <ul>
          {notifications.map((msg, index) => (
            <li key={index} className="mt-2">{msg}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};
